-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-12-2019 a las 04:29:23
-- Versión del servidor: 10.4.8-MariaDB
-- Versión de PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `yt_colores`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `colores`
--

CREATE TABLE `colores` (
  `id_color` int(11) NOT NULL,
  `nom_color` varchar(50) DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `colores`
--

INSERT INTO `colores` (`id_color`, `nom_color`, `descripcion`) VALUES
(1, 'success', 'este es un color verde'),
(2, 'danger', 'esto es un color rojo'),
(8, 'warning', 'esto es un color amarillo'),
(12, 'success', 'esto es un color amarillo'),
(15, 'success', 'ESTE ES UN COLOR VERDE'),
(16, 'warning', 'esto es un color amarillo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `contrasena` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `contrasena`) VALUES
(1, 'ricardito', '$2y$10$DstYcyZSWt6vlEkZ8l5JIO/eA7fnqZDF1akNCfyinnijwdIFBzuh2'),
(2, 'Andres', '$2y$10$GprscMeqv7/ZPumDT5zJGOc5GIvlOTk8daGubPoEp2/Lz0qhati6y'),
(3, 'Andres Ricardo', '$2y$10$vUrzLVOINbEZxfR2YBrOL.qvV/uGEyCPQsQr0cEvGpMroYf5H6j6y'),
(8, 'ricardito1', '$2y$10$leGeAbb2G2HY2AhsuSdvue.PePhtY9a.irz3KqXrNhXEaH9dQzYty'),
(9, NULL, '$2y$10$QIiTDPqbjQNJezxvz8eAr.O8K9usi0fTVIAw7Y/NPopKZ.03YibYO'),
(10, 'php', '$2y$10$7zw80eVGiTS99uU9HyP51e8BnHOGapsehNHdeuD/Cljyuvm70rFk6');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `colores`
--
ALTER TABLE `colores`
  ADD PRIMARY KEY (`id_color`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `colores`
--
ALTER TABLE `colores`
  MODIFY `id_color` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
