<?php

include_once "../yt_colores/conexion.php";

//echo password_hash("ricardo", PASSWORD_DEFAULT)."\n";

//CAPTURAR DATOS POR POST
$usuario_nuevo = $_POST["nombre_usuario"];
$contrasena = $_POST["contrasena"];
$contrasena2 = $_POST["contrasena2"];

$sql = "SELECT * FROM usuarios WHERE nombre = ?";
$sentencia = $db->prepare($sql);
$sentencia->execute(array($usuario_nuevo));
$resultado = $sentencia->fetch();

if ($resultado) {
    echo "El nombre de usuario $usuario_nuevo ya existe";
    die();
}

//HASH CONTRASEÑA
$contrasena = password_hash($contrasena, PASSWORD_DEFAULT);
/*
echo "<pre>";
var_dump($usuario_nuevo);
var_dump($contrasena);
var_dump($contrasena2);
echo "</pre>";
*/
//VERIFICAR CONTRASEÑA
if (password_verify($contrasena2, $contrasena)) {
    echo '¡La contraseña es válida! </br>';
    //AGREGAR A LA BASE DE DATOS
    $sql_agregar = "INSERT INTO usuarios (nombre, contrasena) VALUES(?,?)";
    $sentencia_agregar = $db->prepare($sql_agregar);

    if ($sentencia_agregar->execute(array($usuario_nuevo, $contrasena))) {
        echo " El usuario $usuario_nuevo ha sido Agregado. <br> ";
    } else {
        echo " Error. <br> ";
    }

    //cerramos la conexion de base de datos y sentencia
    $sentencia_agregar = null;
    $db = null;
    //header("Location:index.php");


} else {
    echo "La contraseña no es valida";
}
