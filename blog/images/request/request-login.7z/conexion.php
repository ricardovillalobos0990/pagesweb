<?php
//CONEXION URL - NAME -PASS
$link = "mysql:host=localhost;dbname=yt_colores";
$user = "root";
$pass = "";
//PROBAR LA CONEXION Y MOSTRAR MENJAJE
try {
    $db = new PDO($link, $user, $pass);
    //echo " Conectado <br>";
} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>