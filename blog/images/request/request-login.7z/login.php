<?php
session_start();
include_once "conexion.php";

$usuario_login = $_POST["nombre_usuario"];
$contrasena_login = $_POST["contrasena"];

$sql = "SELECT * FROM usuarios where nombre = ?";
$sentencia = $db->prepare($sql);
$sentencia->execute(array($usuario_login));
$resultado = $sentencia->fetch();

if (!$resultado) {
    echo "No existe usuario";
    die();
}

if (password_verify($contrasena_login, $resultado["contrasena"])) {
    //las contraseñas son iguales
    $_SESSION["admin"] = $usuario_login;
    header("Location:protected.php");
} else {
    echo "No son iguales";
    die();
}