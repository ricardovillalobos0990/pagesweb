<?php
session_start();

if (isset($_SESSION["admin"])) {
    echo "Bienvenido!";
    echo '<br> <a href="cerrar.php"> Cerrar Session </a>';
} else {
    header("Location:registro.php");
}
