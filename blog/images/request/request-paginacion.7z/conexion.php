<?php

$link = "mysql:host=localhost;dbname=paginacion";
$user = "root";
$pass = "";

try {
    $db = new PDO($link, $user, $pass);
    //echo"conectado ";
} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>