<?php
include_once "conexion.php";
$sql = "SELECT * FROM articulos";
$sentencia = $db->prepare($sql);
$sentencia->execute();
$resultado = $sentencia->fetchall();

$art_pag = 3;
//contar articulos de nuestra base de datos
$total_art_paginas = $sentencia->rowCount();
$paginas = $total_art_paginas / 3;
$paginas = ceil($paginas);
?>

<!doctype html>
<html lang="es">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Hello, world!</title>
</head>

<body>
    <div class="container my-5">

        <h1>Paginacion</h1>

        <?php
        if (!$_GET) {
            header("Location:index.php?pagina=1");
        }

        if ($_GET["pagina"] >= $total_art_paginas || $_GET["pagina"] <= 0) {
            header("Location:index.php?pagina=1");
        }

        $iniciar = ($_GET["pagina"] - 1) * $art_pag;

        $sql_articulos = "SELECT * FROM articulos LIMIT :inicio, :final";
        $sentencia_articulos = $db->prepare($sql_articulos);
        $sentencia_articulos->bindParam(':inicio', $iniciar, PDO::PARAM_INT);
        $sentencia_articulos->bindParam(':final', $art_pag, PDO::PARAM_INT);
        $sentencia_articulos->execute();

        $resultado_articulos = $sentencia_articulos->fetchAll();

        ?>

        <?php foreach ($resultado_articulos as $dato) : ?>
            <div class="alert alert-primary" role="alert">
                <?php echo $dato["titulo"] ?>
            </div>
        <?php endforeach ?>

        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item <?php echo $_GET["pagina"] <= 1 ? "disabled" : "" ?>">
                    <a class="page-link" href="index.php?pagina=<?php echo $_GET["pagina"] - 1 ?>">Previous
                    </a>
                </li>
                <?php for ($i = 0; $i < $paginas; $i++) : ?>
                    <li class="page-item <?php echo $_GET["pagina"] == $i + 1 ? "active" : "" ?>">
                        <a class="page-link" href="index.php?pagina=<?php echo $i + 1 ?>">
                            <?php echo $i + 1 ?>
                        </a>
                    </li>
                <?php endfor ?>

                <li class="page-item <?php echo $_GET["pagina"] >= $paginas ? "disabled" : "" ?>">
                    <a class="page-link" href="index.php?pagina=<?php echo $_GET["pagina"] + 1 ?>">Next
                    </a>
                </li>
            </ul>
        </nav>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>