<?php
require "includes/funcs.php";
session_start();

if (isset($_SESSION["id"])) {
    header("Location: form.php");
}

$user_id = $mysqli->real_escape_string($_POST['user_id']);
$token = $mysqli->real_escape_string($_POST['token']);
$password = $mysqli->real_escape_string($_POST['password']);
$con_password = $mysqli->real_escape_string($_POST['con_password']);

?>

<html>

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
	<!-- <script src="https://kit.fontawesome.com/0847ba5d5f.js" crossorigin="anonymous"></script> -->
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<title>Referidos</title>
</head>

<body>

	<div class="container bg-light">
		<div class="row" style="height: 100vh">
			<div id="loginbox" style="margin-top:50px;" class="mainbox col-6 m-auto align-self-center">
				<div class="panel panel-info">
					<h3> Solicitud cambio de contraseña</h3>
					<div style="padding-top:30px" class="panel-body">
						<?php
						if (validaPassword($password, $con_password)) {
							$pass_hash = hashPassword($password);
							if (cambiaPassword($pass_hash, $user_id, $token)) {
								echo "Contraseña Modificada correctamente <br> <a href='index.php' >Iniciar Sesion</a>";
							} else {
								echo "Error al modificar contraseña";
							}
						} else {
							echo 'Las contraseñas no coinciden';
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>