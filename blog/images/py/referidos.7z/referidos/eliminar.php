<?php
session_start();
include_once "includes/conexion.php";
//SI EL LOGIN FUE CORRECTO LA SESSION CONTIENE DATOS DE LO CONTRARIO NO TIENE SESSION INICIADA Y SE REDIRCCIONA AL INICIO
if (!isset($_SESSION["id"])) {
    header("Location: index.php");
}
//VALOR RECIBIDO DESDE EL FORMULARIO
$idpersona = $_GET["idpersona"];
//EN LA FUNCION LOGIN SE ASIGNA EL VALOR DEL ID PERSONAS, EL RESULTADO SE MUESTRA EN PANTALLA EN EL APARTADO DE NAVEGACION
$idsession = $_SESSION["idpersona"];
//CONSULTA PARA INDICAR EL PARENT_ID DEL REFERIDO A EDITAR
$sentencia_eliminar = $mysqli->prepare("SELECT parentid from personas WHERE idpersona = ? LIMIT 1");
$sentencia_eliminar->bind_param("i", $idpersona);
$sentencia_eliminar->execute();
$sentencia_eliminar->store_result();
// $rows = $sentencia_eliminar->num_rows;
$sentencia_eliminar->bind_result($parentid);
$sentencia_eliminar->fetch();
//CONSULTA PARA VERIFICAR QUE LA SESION CORRESPONDA A UN USUARIO EN SU LISTA
$sql_comparar = $mysqli->prepare("SELECT firstName FROM personas WHERE idpersona=? AND parentid=?");
$sql_comparar->bind_param("ii", $idpersona,  $idsession);
$sql_comparar->execute();
$sql_comparar->store_result();
$rowComparacion = $sql_comparar->num_rows;
// SI EXISTEN RESULTADOS SE ACTUALIZAN LOS PARIENTES DEL SEGUNDO NIVEL Y SE PROCEDE A BORRAR AL USUARIO
if ($rowComparacion > 0) {
    $sentencia_actualizar = $mysqli->prepare("UPDATE personas SET parentid=? WHERE parentid=? ");
    $sentencia_actualizar->bind_param("ii", $parentid, $idpersona);
    //SI SE ACTUALIZAN LOS PARENT ID CORRECTAMENTE
    if ($sentencia_actualizar->execute()) {
        $sql_eliminar = $mysqli->prepare("DELETE FROM personas WHERE idpersona = ?");
        $sql_eliminar->bind_param("i", $idpersona);
        $sql_eliminar->execute();
        header("location:form.php");
    }
}