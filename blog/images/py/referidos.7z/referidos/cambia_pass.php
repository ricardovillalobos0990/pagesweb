<?php
require "includes/funcs.php";
session_start();

if (empty($_GET['user_id'])) {
    header('Location: index.php');
}

if (empty($_GET['token'])) {
    header('Location: index.php');
}

$user_id = $mysqli->real_escape_string($_GET['user_id']);
$token = $mysqli->real_escape_string($_GET['token']);

if (!verificaTokenPass($user_id, $token)) {
    echo 'No se pudo verificar los Datos';
    exit;
}
?>
<html>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <!-- <script src="https://kit.fontawesome.com/0847ba5d5f.js" crossorigin="anonymous"></script> -->
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <title>Referidos</title>
</head>

<body>

    <div class="container bg-light">
        <div class="row" style="height: 100vh">
            <div id="loginbox" style="margin-top:50px;" class="mainbox col-6 m-auto align-self-center">
                <div class="panel panel-info">
                    <div style="padding-top:30px" class="panel-body">
                        <form id="loginform" class="form-horizontal" role="form" action="guarda_pass.php" method="POST" autocomplete="off">
                            <div class="panel-heading my-3">
                                <div class="panel-title tex-center h3">Cambiar Contraseña</div>
                            </div>
                            <input type="hidden" id="user_id" name="user_id" value="<?php echo $user_id; ?>" />
                            <input type="hidden" id="token" name="token" value="<?php echo $token; ?>" />
                            <div class="form-group">
                                <label for="password" class="col-md-6 control-label">Nueva contraseña</label>
                                <div class="col-md-9">
                                    <input type="password" class="form-control" name="password" placeholder="Contraseña" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="con_password" class="col-md-6 control-label">Confirmar Contraseña</label>
                                <div class="col-md-9">
                                    <input type="password" class="form-control" name="con_password" placeholder="Confirmar" required>
                                </div>
                            </div>

                            <div style="margin-top:10px" class="form-group">
                                <div class="col-sm-12 controls">
                                    <button id="btn-login" type="submit" class="btn btn-success">Modificar</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>