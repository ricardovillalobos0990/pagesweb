<?php
//session_start() crea una sesión o reanuda la actual basada en un identificador de sesión pasado mediante una petición GET o POST, o pasado mediante una cookie.
session_start();
//require es idéntico a include excepto que en caso de fallo producirá un error fatal de nivel E_COMPILE_ERROR. En otras palabras, éste detiene el script mientras que include sólo emitirá una advertencia (E_WARNING) lo cual permite continuar el script.
require "includes/funcs.php";
//Variable para almacenar los errores
$errors = array();
//empty — Determina si una variable está vacía
if (!empty($_POST)) {
    /*
    Se capturan los valores del formulario
    Escapa los caracteres especiales de una cadena para usarla en una sentencia SQL,
    */
    $id = $mysqli->real_escape_string($_POST["id"]);
    $password = $mysqli->real_escape_string($_POST["password"]);
    $captcha = $mysqli->real_escape_string($_POST["g-recaptcha-response"]);
    $secret = "6Ldi28oUAAAAANQ7rl0njr6WYqzsf5PJF6Wg1I4L";
    //Se envian dos parametros para validar con la funncion isNullLogin que todos los caampos contengan registros
    if (isNullLogin($id, $password)) {
        $errors[] = "Debe llenar todos los campos";
    }
    //Validacion del si no se seleeciona
    if (!$captcha) {
        $errors[] = "Por favor verifica el captcha";
    }
    //Si la cantidad de errores es igual a 0
    if (count($errors) == 0) {
        //Se toma la respuesta con la variable secret y el valor de la respuesta
        $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$captcha");
        $arr = json_decode($response, TRUE);
        /*
        Si se comprueba los campos correctamente se llama a la funcion login la cual recibe los parametros de
        identificacion o cedula y la contraseña 
        */
        if ($arr['success']) {
            $errors[] = login($id, $password);
        } else {
            $errors[] = "Error al comprobar captcha";
        }
    }
}

?>

<!doctype html>
<html lang="es">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- DESCRIPCION DEL SITIO -->
    <meta name="description" content="Sistema referidos">
    <meta name="author" content="sistema referidos">
    <meta name="keywords" content="referidos, usuarios sistema, aplicacion">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <!-- RECAPTCHA -->
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <title>Sistema Referidos</title>
</head>

<body>
    <!-- CONTAINER -->
    <div class="container text-center bg-light">
        <div class="row justify-content-center" style="height: 100vh">
            <div class="col-4 align-self-center">
                <form class="form-signin" id="form" action="<?php $_SERVER["PHP_SELF"]; ?>" method="POST">
                    <img class="mb-4 img-fluid" src="./images/login/logo-p.jpg" alt="" width="72" height="72">
                    <h1 class="h3 mb-3 font-weight-normal">Sistema referidos</h1>
                    <input type="text" id="inputId" class="form-control my-3" placeholder="Usuario" autofocus="" name="id" required="">
                    <div class="form-group">
                        <div class="input-group-prepend" id="show_hide_password">
                            <input type="password" id="inputPassword" class="form-control" placeholder="password" required="" name="password">
                            <div class="input-group-text">
                                <a href=""><i class="fa fa-eye-slash" aria-hidden="true" id="inputIcon"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="g-recaptcha" data-sitekey="6Ldi28oUAAAAANf3F2VciHe8nI_Zp1vWF6sG1afD"></div>
                    <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
                    <div style="float:right; font-size: 80%; position: relative; top:20px"><a href="recupera.php">¿Se te olvid&oacute; tu contraseña?</a></div>
                    <p class="mt-5 mb-3 text-muted">© 2020</p>
                </form>
                <!-- IMPRESION DE ERRORES -->
                <?php echo resultBlock($errors); ?>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="js/show.js"></script>

</body>

</html>