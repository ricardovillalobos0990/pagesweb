<?php
	require ('conexion.php');
	$idciudad = $_POST['idciudad'];
	$queryM = "SELECT idcpo, namcpo FROM cpo WHERE cities_idcity = $idciudad ORDER BY namcpo ASC;";
	$resultadoP = $mysqli->query($queryM);
	$html= "<option value='0'>Seleccionar Municipio</option>";
	while($rowP = $resultadoP->fetch_assoc())
	{
		$html.= "<option value='".$rowP['idcpo']."'>".$rowP['namcpo']."</option>";
	}
	echo $html;
?>