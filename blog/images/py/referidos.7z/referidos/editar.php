<?php
//session_start() crea una sesión o reanuda la actual basada en un identificador de sesión pasado mediante una petición GET o POST, o pasado mediante una cookie.
session_start();
//require es idéntico a include excepto que en caso de fallo producirá un error fatal de nivel E_COMPILE_ERROR. En otras palabras, éste detiene el script mientras que include sólo emitirá una advertencia (E_WARNING) lo cual permite continuar el script.
include_once "includes/funcs.php";
//SI EL LOGIN FUE CORRECTO LA SESSION CONTIENE DATOS DE LO CONTRARIO NO TIENE SESSION INICIADA Y SE REDIRCCIONA AL INICIO
if (!isset($_SESSION["id"])) {
    header("Location: index.php");
}

//EN LA FUNCION LOGIN SE ASIGNA EL VALOR DEL ID PERSONAS, EL RESULTADO SE MUESTRA EN PANTALLA EN EL APARTADO DE NAVEGACION
$ids = $_SESSION["id"];
$idp = $_SESSION["idpersona"];

//CONSULTA PARA MOSTRAR EN LA NAVEGACION EL NOMBRE Y APELLIDO
$resultadoPersonas = $mysqli->query("SELECT id, firstName, lastName FROM personas WHERE id = $ids");
$row = $resultadoPersonas->fetch_assoc();

//CONSULTA PARA TRAER LOS CAMPOS DE LOS DEPARTAMENTOS EL CUAL SE MUESTRA CON PHP
$sql = "SELECT * FROM departments ORDER BY namdepartment asc";
$resDepartment = $mysqli->query($sql);

//CONSULTA PARA MOSTRAR LOS DATOS PARA EDITAR DE LA PERSONA REFERIDA
$idreferido = $_GET["idpersona"];
$sqlreferidos = $mysqli->query("SELECT firstName, lastName, id, date, mobile, phone, address, email, password, activacion, token, latitude, longitude, gender,
sectors_idsector, candidate_idcandidate, persis_idpersis, parentid
FROM personas WHERE idpersona= $idreferido AND parentid = $idp ");
$rowRe = $sqlreferidos->fetch_assoc();

//REGISTRAR USUARIO
$errors = array();
if (!empty($_POST)) {
    $latitude = $mysqli->real_escape_string($_POST["latitude"]);
    $longitude = $mysqli->real_escape_string($_POST["longitude"]);
    $firstName = $mysqli->real_escape_string($_POST["firstName"]);
    $lastName = $mysqli->real_escape_string($_POST["lastName"]);
    $id = $mysqli->real_escape_string($_POST["id"]);
    $email = $mysqli->real_escape_string($_POST["email"]);
    $gender = $mysqli->real_escape_string($_POST["gender"]);
    $date = $mysqli->real_escape_string($_POST["date"]);
    $mobile = $mysqli->real_escape_string($_POST["mobile"]);
    $phone = $mysqli->real_escape_string($_POST["phone"]);
    $department = $mysqli->real_escape_string($_POST["namdepartment"]);
    $city = $mysqli->real_escape_string($_POST["namcity"]);
    $populated = $mysqli->real_escape_string($_POST["namcpo"]);
    $sector = $mysqli->real_escape_string($_POST["namsector"]);
    $stratum = $mysqli->real_escape_string($_POST["stratum"]);
    $address = $mysqli->real_escape_string($_POST["address"]);
    $referred = $mysqli->real_escape_string($_POST["referred"]);
    $senate = $mysqli->real_escape_string($_POST["senate"]);
    $password = $mysqli->real_escape_string($_POST["enviar"]);

    //EN EL LOGIN SE CAPTURA EL ID DE LA PERSONA EL CUAL SE ASIGNA COMO PARENT ID DEL USUARIO A REGISTRAR
    $parentid = $_SESSION['idpersona'];
    $activo = 0;

    //SE GENERA UNA CONTRASÑEA ALEAORIA
    if (isset($_POST['enviar'])) {
        //Carácteres para la contraseña
        $str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        $password = "";
        //Reconstruimos la contraseña segun la longitud que se quiera
        for ($i = 0; $i < 12; $i++) {
            //obtenemos un caracter aleatorio escogido de la cadena de caracteres
            $password .= substr($str, rand(0, 62), 1);
        }
    }

    //SE VALIDAN LOS CAMPOS DEL FORMULARIO
    if (isNull($latitude, $longitude, $firstName, $lastName, $id, $email, $gender, $date, $mobile, $department, $city, $populated, $sector, $stratum, $address, $referred, $senate)) {
        $errors[] = "Debe llenar todos los campos";
    }

    //SE VALIDA CORREO ELECTRONICO VALIDO
    if (!isEmail($email)) {
        $errors[] = "Direccion de correo invalida";
    }

    //SE VALIDA SI ES USUARIO QUE EDITA ES REFERIO O NO DE LA PERSONA
    if ($rowRe == NULL) {
        $errors[] = "Este usuario no es referido por usted por favor elija uno de sus postulados para cambiar los datos";
    }

    //SI NO HAY ERRORES CONTINUA
    if (count($errors) == 0) {
        //SE GENERA CONTRASEÑA ENCRIPTADA Y TOKEN ALEATORIO
        $pass_hash = hashPassword($password);
        $token = generateToken();
        //SE VALIDA SI EL SECTOR ES NUEVO O YA EXISTE LOS DATOS
        $validarSector = validarSector($sector, $stratum, $populated);
        //SE REGISTRA USUARIO NUEVO
        $actualizarRegitro = actualizarUsuario($firstName, $lastName, $date, $mobile, $phone, $address, $email, $pass_hash, $activo, $token, $latitude, $longitude, $gender, $validarSector, $senate, $referred, $idreferido);
        echo $actualizarRegitro;
        if ($actualizarRegitro > 0 && $referred == 5) {
            $url = 'http://' . $_SERVER["SERVER_NAME"] . '/php/referidos/activar.php?id=' . $actualizarRegitro . '&val=' . $token;
            $asunto = 'Activar Cuenta - Sistema de Usuarios';
            $cuerpo =
                " Estimado $firstName: <br /><br />
            Para continuar con el proceso de registro, es indispensable de click en el siguiente link para activar su cuenta <a href='$url'>Activar Cuenta</a>
            <table>
                <tr>
                    <th> Ingreso al sistema</th>
                    <th> http://localhost/php/referidos/ </th>
                </tr>
                <tr>
                    <th> Correo </th>
                    <th> $email </th>
                </tr>
                <tr>
                    <th> Nombre </th>
                    <th> $firstName </th>
                </tr>
                <tr>
                    <th> Usuario </th>
                    <th> $id </th>
                </tr>
                <tr>
                    <th> Clave </th>
                    <th> $password </th>
                </tr>
                <tr>
                    <th> Cedula referido por </th>
                    <th> $parentid </th>
                </tr>
            ";
            if (enviarEmail($email, $firstName, $asunto, $cuerpo)) {
                $notification[]  = "Se enviaron los datos de acceso al correo: $email";
            } else {
                $errors[] = "Error al enviar el correo electronico";
            };
        } else {
            //header("Location: form.php");
            $errors[] = "Siguiente usuario";
        }
    }
}

?>

<!doctype html>
<html lang="es">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- DESCRIPCION DEL SITIO -->
    <meta name="description" content="Sistema referidos">
    <meta name="author" content="sistema referidos">
    <meta name="keywords" content="referidos, usuarios sistema, aplicacion">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <title>Editar Referidos</title>
</head>

<body>
    <!-- NAVEGACION -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <a class="navbar-brand" href="#">Referidos</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-item nav-link" href="#">Inicio <span class="sr-only">(current)</span></a>
                <a class="nav-item nav-link active" href="#">Registro</a>
                <a class="nav-item nav-link" href="#">Contacto</a>
            </div>
            <?php if ($_SESSION["idpersis"] == 1) { ?>
                <div class="navbar-nav ml-auto">
                    <a class="nav-item nav-link ml-auto" href="#">Cerrar Administrador </a>
                </div>
            <?php } ?>
            <?php if ($_SESSION["idpersis"] == 5) { ?>
                <div class="navbar-nav ml-auto">
                    <a class="nav-item nav-link ml-auto" href="#"><?php echo 'Bienvenid@ ' . utf8_decode($row['firstName'] . " " . $row['lastName']); ?></a>
                </div>
            <?php } ?>
            <div class="navbar-nav ml-auto">
                <a class="nav-item nav-link ml-auto" href="logout.php">Cerrar session </a>
            </div>
        </div>
    </nav>
    <!-- CONTAINER -->
    <div class="container bg-light my-3">
        <div class="py-5 text-center">
            <img class="d-block mx-auto mb-4" src="./images/login/logo-p.jpg" alt="logo-campaña" width="72" height="72">
            <h2>Bienvenido</h2>
            <p class="lead">
                Edite los datos de la persona en el formulario, recuerde que todos los campos son obligatorios.
            </p>
        </div>
        <!--DATOS REFERIDOS -->
        <form method="POST" action="<?php $_SERVER['PHP_SELF'] ?>">
            <div class="row bg-light">
                <!-- DATOS GENERALES -->
                <div class="col-md-8">
                    <h4 class="my-4 text-center">Datos referidos</h4>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 mb-3">
                            <label for="firstName">Nombre<span class="text-muted">(*)</span></label>
                            <input type="text" class="form-control" id="firstName" name="firstName" placeholder="Nombre" required="" value="<?php echo $rowRe["firstName"] ?>">
                            <div class="invalid-feedback">
                                Se requiere un nombre válido..
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 mb-3">
                            <label for="lastName">Apellido<span class="text-muted">(*)</span></label>
                            <input type="text" class="form-control" id="lastName" name="lastName" placeholder="Apellido" required="" value="<?php echo $rowRe["lastName"] ?>">
                            <div class="invalid-feedback">
                                Se requiere apellido válido.
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 mb-3">
                            <label for="id" >Cedula <span class="text-muted" >(*)</span></label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">CC</span>
                                </div>
                                <input type="number" class="form-control" disabled id="id" name="id" placeholder="identificación" required="" value="<?php echo $rowRe["id"] ?>">
                                <div class="invalid-feedback" style="width: 100%;">
                                    Se requiere una cedula es obligatorio..
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 mb-3">
                            <label for="email">Email <span class="text-muted">(*)</span></label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="correo@ejemplo.com" required="" value="<?php echo $rowRe["email"] ?>">
                            <div class="invalid-feedback">
                                Ingrese una dirección de correo electrónico válida.
                            </div>
                        </div>
                        <fieldset class="form-group col-12">
                            <div class="row">
                                <legend class="col-form-label col-sm-2 pt-0">Sexo</legend>
                                <div class="col-sm-10">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="gender" id="gridRadios1" value="Masculino" checked>
                                        <label class="form-check-label" for="gender1">Hombre</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="gender" id="gridRadios2" value="Femenino">
                                        <label class="form-check-label" for="gender2">Mujer</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="gender" id="gridRadios3" value="Otro">
                                        <label class="form-check-label" for="gender3">Otro</label>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
                <!-- LOCALIZACION -->
                <div class="col-md-4 col-sm-12 posicion my-4">
                    <h4 class="d-flex justify-content-between align-items-center">
                        <span class="text-muted">Localización</span>
                        <i class="fa fa-map-marker"></i>
                    </h4>
                    <ul class="list-group">
                        <li class="list-group-item">
                            <div>
                                <h6 class="mb-3 latitude" id="Latitud">Latitud</h6>
                                <input type="text" class="form-control" id="latitude" name="latitude" required="" value="<?php echo $rowRe["latitude"] ?>">
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div>
                                <h6 class="mb-3">Longitud</h6>
                                <input type="text" class="form-control" id="longitude" name="longitude" required="" value="<?php echo $rowRe["longitude"] ?>">
                            </div>
                        </li>
                    </ul>
                    <div class="input-group-append ">
                        <button id="geo" type="submit" class="btn btn-primary btn-block">Localizar</button>
                    </div>
                </div>
                <!-- RESIDENCIA -->
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-4 col-sm-6 mb-3">
                            <label for="date">Fecha de nacimiento</label>
                            <input type="date" class="form-control" id="date" name="date" placeholder="dd/mm/aa" min="1920-01-25" required="" value="<?php echo $rowRe["date"] ?>">
                            <div class="invalid-feedback">
                                Indique su fecha de nacimiento.
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 mb-3">
                            <label for="mobile">Celular<span class="text-muted">(*)</span></label>
                            <input type="number" class="form-control" id="mobile" name="mobile" placeholder="Numero" required="" value="<?php echo $rowRe["mobile"] ?>">
                            <div class="invalid-feedback">
                                Se requiere un numero valido.
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 mb-3">
                            <label for="phone">Telefono<span class="text-muted">(Optional)</span></label>
                            <input type="number" class="form-control" id="phone" name="phone" placeholder="Numero" value="<?php echo $rowRe["phone"] ?>">
                            <div class="invalid-feedback">
                                Se requiere apellido válido.
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 mb-3">
                            <label for="department">Departamento<span class="text-muted">(*)</span></label>
                            <select class="custom-select d-block w-100" id="department" name="namdepartment" required="">
                                <option value="0"> ... </option>
                                <?php while ($row = $resDepartment->fetch_assoc()) : ?>
                                    <option value="<?php echo $row["iddepartment"] ?>">
                                        <?php echo $row["namdepartment"] ?>
                                    </option>
                                <?php endwhile ?>
                            </select>
                            <div class="invalid-feedback">
                                Please select a valid country.
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 mb-3">
                            <label for="city">Ciudad<span class="text-muted">(*)</span></label>
                            <select class="custom-select d-block w-100" id="city" name="namcity" required="">

                            </select>
                            <div class="invalid-feedback">
                                Please provide a valid Department.
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 mb-3">
                            <label for="populated ">Centro Poblado<span class="text-muted">(*)</span></label>
                            <select class="custom-select d-block w-100" id="populated" name="namcpo" required="">

                            </select>
                            <div class="invalid-feedback">
                                Please provide a valid Department.
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-5 mb-3">
                            <label for="sector">Barrio<span class="text-muted">(*)</span></label>
                            <input type="text" class="form-control" id="sector" name="namsector" placeholder="Barrio" required="">

                            <div class="invalid-feedback">
                                Please provide a valid sector.
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-5 mb-3">
                            <label for="address">Direccion <span class="text-muted">(*)</span></label>
                            <input type="text" class="form-control" id="address" name="address" placeholder="Avenida, carrera, calle" required="">
                        </div>
                        <div class="col-md-2 col-sm-2 mb-3">
                            <label for="stratum">Estrato<span class="text-muted">(*)</span></label>
                            <select class="custom-select d-block w-100" id="stratum" name="stratum" required="">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                            </select>
                            <div class="invalid-feedback">
                                Please provide a valid stratum.
                            </div>
                        </div>
                        <fieldset class="form-group col-12">
                            <div class="row">
                                <legend class="col-form-label col-sm-4 pt-0"> Tipo de referido</legend>
                                <div class="col-sm-8">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="referred" id="referred1" value="2" checked>
                                        <label class="form-check-label" for="referred1">Referido</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="referred" id="referred2" value="5">
                                        <label class="form-check-label" for="referred2">Usuario</label>
                                    </div>
                                </div>
                            </div>
                            <hr class="mb-4">
                        </fieldset>
                    </div>
                    <!-- CANDIDATO -->
                    <h4 class="mb-3">Candidato</h4>
                    <p class="lead">
                        Seleccione el candidato con su intencion de voto
                    </p>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="senate">Senado</label>
                            <select class="custom-select d-block w-100" name="senate" required="">
                                <option value="1">Candidato 1</option>
                                <option value="2"> Candidato 2</option>
                            </select>
                            <div class="invalid-feedback">
                                Seleccione una opcion valida.
                            </div>
                        </div>
                    </div>
                    <hr class="mb-4">
                    <button class="btn btn-primary btn-lg btn-block mb-4" name="enviar">Registrar</button>
                </div>
            </div>
        </form>
        <?php echo resultBlock($errors); ?>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="js/localization.js"></script>
</body>

</html>