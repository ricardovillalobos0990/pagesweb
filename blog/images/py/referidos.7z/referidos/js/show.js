document.getElementById("inputIcon").addEventListener("click", (event) => {
    event.preventDefault();
    const mostrar = document.getElementById("inputPassword")
    const mostrarIcono = document.getElementById("inputIcon");
    //CONDICIONAL PARA CAMBIAR EL INPUT DEL PASSWORD DE TEXTO O CONTRASEÑA
    if (mostrar.getAttribute("type") == "text") {
        mostrar.setAttribute('type', 'password');
        mostrarIcono.setAttribute('class', 'fa fa-eye-slash');
    } else if (mostrar.getAttribute("type") == "password") {
        mostrar.setAttribute('type', 'text');
        mostrarIcono.setAttribute('class', 'fa fa-eye');
    }
})