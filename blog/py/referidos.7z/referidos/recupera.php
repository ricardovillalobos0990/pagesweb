<?php
include_once "includes/funcs.php";

session_start();

if (isset($_SESSION["id"])) {
    header("Location: form.php");
}

$errors = array();
$notification = array();

if (!empty($_POST)) {
    $email = $mysqli->real_escape_string($_POST['email']);

    if (!isEmail($email)) {
        $errors[] = "Debe ingresar un correo electronico valido";
    }

    if (emailExiste($email)) {
        $user_id = getValor('idpersona', 'email', $email);
        $nombre = getValor('firstName', 'email', $email);

        $token = generaTokenPass($user_id);

        $url = 'http://' . $_SERVER["SERVER_NAME"] . '/php/referidos/cambia_pass.php?user_id=' . $user_id . '&token=' . $token;

        $asunto = 'Recuperar Password - Sistema de Usuarios';
        $cuerpo = "Hola $nombre: <br /><br />Se ha solicitado un reinicio de contrase&ntilde;a. <br/><br/>Para restaurar la contrase&ntilde;a, visita la siguiente direcci&oacute;n: <a href='$url'> Cambiar contrase&ntilde;a </a>";

        if (enviarEmail($email, $nombre, $asunto, $cuerpo)) {
            $notification []= "Hemos enviado un correo electronico a la direccion $email para restablecer tu contraseña.<br />";
            $notification[] = "<a href='index.php' >Iniciar Sesion</a>";
        }
    } else {
        $errors[] = "La direccion de correo electronico no existe";
    }
}
?>
<html>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <!-- <script src="https://kit.fontawesome.com/0847ba5d5f.js" crossorigin="anonymous"></script> -->
    <title>Referidos</title>
</head>

<body>
    <div class="container bg-light">
        <div class="row" style="height: 100vh">
            <div id="loginbox" style="margin-top:50px;" class="mainbox col-4 m-auto align-self-center text-center">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <div class="panel-title h4">Recuperar Contraseña</div>
                    </div>
                    <div class="panel-body">
                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
                        <form id="loginform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" autocomplete="off">
                            <div class="input-group-prepend my-5 ">
                                <span class="input-group-text">  </span>
                                <input id="email" type="email" class="form-control" name="email" placeholder="email" required>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12 controls">
                                    <button id="btn-login" type="submit" class="btn btn-success btn-lg btn-block">Solicitar</a>
                                </div>
                            </div>
                        </form>
                        <?php echo resultBlock($errors); ?>
                        <?php echo resultBlock($notification); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>