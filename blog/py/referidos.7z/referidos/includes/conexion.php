<?php
$mysqli = new mysqli("localhost", "root", "", "referidos");
if(mysqli_connect_errno()){
    echo "Conexion Fallida";
    die();
}
?>