<?php
	require ('conexion.php');
	$iddepartment = $_POST['iddepartment'];
	$queryM = "SELECT idcity, namcity FROM cities WHERE departments_iddepartment = $iddepartment ORDER BY namcity asc";
	$resultadoM = $mysqli->query($queryM);
	$html= "<option value='0'>Seleccionar Municipio</option>";
	while($rowM = $resultadoM->fetch_assoc())
	{
		$html.= "<option value='".$rowM['idcity']."'>".$rowM['namcity']."</option>";
	}
	echo $html;
?>