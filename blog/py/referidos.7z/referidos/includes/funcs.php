<?php
require "includes/conexion.php";
require "./lib/PHPMailer/src/PHPMailer.php";
require "./lib/PHPMailer/src/SMTP.php";
require "./lib/PHPMailer/src/Exception.php";

use PHPMailer\PHPMailer\PHPMailer;

global $mysqli;

function isNullLogin($usuario, $password)
{
	if (strlen(trim($usuario)) < 1 || strlen(trim($password)) < 1) {
		return true;
	} else {
		return false;
	}
}
function login($usuario, $password)
{
	global $mysqli;
	$stmt = $mysqli->prepare("SELECT idpersona, id, persis_idpersis, password FROM personas WHERE id = ? || email = ? LIMIT 1");
	$stmt->bind_param("ss", $usuario, $usuario);
	$stmt->execute();
	$stmt->store_result();
	$rows = $stmt->num_rows;

	if ($rows > 0) {

		if (isActivo($usuario)) {
			$stmt->bind_result($idpersona, $id, $persis_idpersis, $passwd);
			$stmt->fetch();
			$validaPassw = password_verify($password, $passwd);
			if ($validaPassw) {

				lastSession($id);

				$_SESSION['idpersona'] = $idpersona;
				$_SESSION['id'] = $id;
				$_SESSION['idpersis'] = $persis_idpersis;

				header("location: form.php");
			} else {
				$errors = "La contrase&ntilde;a es incorrecta";
			}
		} else {
			$errors = 'El usuario no esta activo';
		}
	} else {
		$errors = "El nombre de usuario o correo electr&oacute;nico no existe";
	}
	return $errors;
}
function isNull($latitude, $longitude, $firstName, $lastName, $id, $email, $gender, $date, $mobile, $department, $city, $populated, $sector, $stratum, $address, $referred, $senate)
{
	if (
		strlen(trim($latitude)) < 1 || strlen(trim($longitude)) < 1 ||
		strlen(trim($firstName)) < 1 || strlen(trim($lastName)) < 1 ||
		strlen(trim($id)) < 1 || strlen(trim($email)) < 1 ||
		strlen(trim($gender)) < 1 || strlen(trim($date)) < 1 ||
		strlen(trim($mobile)) < 1 || strlen(trim($department)) < 1 ||
		strlen(trim($city)) < 1 || strlen(trim($populated)) < 1 ||
		strlen(trim($sector)) < 1 || strlen(trim($stratum)) < 1 ||
		strlen(trim($address)) < 1 || strlen(trim($referred)) < 1 ||
		strlen(trim($senate)) < 1

	) {
		return true;
	} else {
		return false;
	}
}
function isEmail($email)
{
	if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
		return true;
	} else {
		return false;
	}
}
function usuarioExiste($identificacion)
{
	global $mysqli;
	$stmt = $mysqli->prepare("SELECT id FROM personas WHERE id = ? LIMIT 1");
	$stmt->bind_param("s", $identificacion);
	$stmt->execute();
	$stmt->store_result();
	$num = $stmt->num_rows;
	$stmt->close();

	if ($num > 0) {
		return true;
	} else {
		return false;
	}
}
function emailExiste($email)
{
	global $mysqli;

	$stmt = $mysqli->prepare("SELECT id FROM personas WHERE email = ? LIMIT 1");
	$stmt->bind_param("s", $email);
	$stmt->execute();
	$stmt->store_result();
	$num = $stmt->num_rows;
	$stmt->close();

	if ($num > 0) {
		return true;
	} else {
		return false;
	}
}
function hashPassword($password)
{
	$hash = password_hash($password, PASSWORD_DEFAULT);
	return $hash;
}
function generateToken()
{
	$gen = md5(uniqid(mt_rand(), false));
	return $gen;
}
function validarSector($sector, $stratum, $populated)
{
	global $mysqli;
	// $idsector = "idsector";
	$valCiudad = $mysqli->prepare("SELECT idsector FROM sectors WHERE namsector = ? AND stratum = ? LIMIT 1");
	$valCiudad->bind_param("si", $sector, $stratum);
	$valCiudad->execute();
	$valCiudad->store_result();
	$num = $valCiudad->num_rows;

	if ($num > 0) {
		$valCiudad->bind_result($idsector);
		$valCiudad->fetch();
		return $idsector;
	} else {
		$idsector = registrarSector($sector, $stratum, $populated);
		return  $idsector;
	}
}
function registrarSector($sector, $stratum, $populated)
{
	global $mysqli;
	$regCiudad = $mysqli->prepare("INSERT INTO sectors(namsector, stratum, cpo_idcpo) VALUES(?,?,?)");
	$regCiudad->bind_param('sii', $sector, $stratum, $populated);
	if ($regCiudad->execute()) {
		return $mysqli->insert_id;
	} else {
		return 0;
	}
}
function registraUsuario($firstName, $lastName, $id, $date, $mobile, $phone, $address, $email, $pass_hash, $activo, $token, $latitude, $longitude, $gender, $sector, $senate, $referred, $parentid)
{
	global $mysqli;
	$stmt = $mysqli->prepare("INSERT INTO personas(firstName, lastName, id, date, mobile, phone, address, email, password, activacion, token, latitude, longitude, gender, sectors_idsector, candidate_idcandidate, persis_idpersis, parentid) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
	$stmt->bind_param('ssissssssissssiiii', $firstName, $lastName, $id, $date, $mobile, $phone, $address, $email, $pass_hash, $activo, $token, $latitude, $longitude, $gender, $sector, $senate, $referred, $parentid);
	if ($stmt->execute()) {
		return $mysqli->insert_id;
	} else {
		return 0;
	}
}
function enviarEmail($email, $firstName, $asunto, $cuerpo)
{

	$mailer = new PHPMailer();
	/* AUTENTICACION */
	$mailer->isSMTP();
	$mailer->SMTPAuth = true;
	$mailer->SMTPSecure = "tls";
	$mailer->Host = "smtp.gmail.com";
	$mailer->Port = "587";
	$mailer->Username = "sucorreo@gmail.com"; //Correo de donde enviaremos los correos
	$mailer->Password = ""; // Password de la cuenta de envío
	/* CUERPO */
	$mailer->setFrom("ricardovillalobos@gmail.com", "Sistema referidos");
	$mailer->addAddress($email, $firstName);  //Correo receptor
	$mailer->Subject = $asunto;;
	$mailer->Body = $cuerpo;
	$mailer->IsHTML(true);

	if ($mailer->send()) {
		return true;
	} else {
		return false;
	}
}
function validaPassword($var1, $var2)
{
	if (strcmp($var1, $var2) !== 0) {
		return false;
	} else {
		return true;
	}
}
function validaIdToken($idpersona, $token)
{
	global $mysqli;

	$stmt = $mysqli->prepare("SELECT activacion FROM personas WHERE idpersona = ? AND token = ? LIMIT 1");
	$stmt->bind_param("is", $idpersona, $token);
	$stmt->execute();
	$stmt->store_result();
	$rows = $stmt->num_rows;

	if ($rows > 0) {
		$stmt->bind_result($activacion);
		$stmt->fetch();

		if ($activacion == 1) {
			$msg = "La cuenta ya se activo anteriormente.";
		} else {
			if (activarUsuario($idpersona)) {
				$msg = 'Cuenta activada.';
			} else {
				$msg = 'Error al Activar Cuenta';
			}
		}
	} else {
		$msg = 'No existe el registro para activar.';
	}
	return $msg;
}
function activarUsuario($idpersona)
{
	global $mysqli;

	$stmt = $mysqli->prepare("UPDATE personas SET activacion=1, token='' WHERE idpersona = ?");
	$stmt->bind_param('s', $idpersona);
	$result = $stmt->execute();
	$stmt->close();
	return $result;
}
function lastSession($id)
{
	global $mysqli;

	$stmt = $mysqli->prepare("UPDATE personas SET lastsession=NOW(), tokenpassword='', passwordrequest=1 WHERE id = ?");
	$stmt->bind_param('s', $id);
	$stmt->execute();
	$stmt->close();
}
function isActivo($usuario)
{
	global $mysqli;

	$stmt = $mysqli->prepare("SELECT activacion FROM personas WHERE id = ? || email = ? LIMIT 1");
	$stmt->bind_param('ss', $usuario, $usuario);
	$stmt->execute();
	$stmt->bind_result($activacion);
	$stmt->fetch();

	if ($activacion == 1) {
		return true;
	} else {
		return false;
	}
}
function generaTokenPass($user_id)
{
	global $mysqli;

	$token = generateToken();

	$stmt = $mysqli->prepare("UPDATE personas SET tokenpassword=?, passwordrequest=1 WHERE idpersona = ?");
	$stmt->bind_param('ss', $token, $user_id);
	$stmt->execute();
	$stmt->close();

	return $token;
}
function getValor($campo, $campoWhere, $valor)
{
	global $mysqli;

	$stmt = $mysqli->prepare("SELECT $campo FROM personas WHERE $campoWhere = ? LIMIT 1");
	$stmt->bind_param('s', $valor);
	$stmt->execute();
	$stmt->store_result();
	$num = $stmt->num_rows;

	if ($num > 0) {
		$stmt->bind_result($_campo);
		$stmt->fetch();
		return $_campo;
	} else {
		return null;
	}
}
function getPasswordRequest($id)
{
	global $mysqli;

	$stmt = $mysqli->prepare("SELECT passwordrequest FROM personas WHERE id = ?");
	$stmt->bind_param('i', $id);
	$stmt->execute();
	$stmt->bind_result($_id);
	$stmt->fetch();

	if ($_id == 1) {
		return true;
	} else {
		return null;
	}
}
function verificaTokenPass($user_id, $token)
{
	global $mysqli;
	$stmt = $mysqli->prepare("SELECT activacion FROM personas WHERE idpersona = ? AND tokenpassword = ? AND passwordrequest = 1 LIMIT 1");
	$stmt->bind_param('is', $user_id, $token);
	$stmt->execute();
	$stmt->store_result();
	$num = $stmt->num_rows;
	if ($num > 0) {
		$stmt->bind_result($activacion);
		$stmt->fetch();
		if ($activacion == 1) {
			return true;
		} else {
			return false;
		}
	} else {
		return false;
	}
}
function cambiaPassword($password, $user_id, $token)
{
	global $mysqli;
	$stmt = $mysqli->prepare("UPDATE personas SET password = ?, tokenpassword='', passwordrequest=0 WHERE idpersona = ? AND tokenpassword = ?");
	$stmt->bind_param('sis', $password, $user_id, $token);

	if ($stmt->execute()) {
		return true;
	} else {
		return false;
	}
}
function resultBlock($errors)
{
	if (count($errors) > 0) {
		echo "<div id='error' class='alert alert-warning alert-dismissible fade show' role='alert'>
			<button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			<span aria-hidden='true'>&times;</span>
			</button>
			<ul>";
		foreach ($errors as $error) {
			echo "<li>" . $error . "</li>";
		}
		echo "</ul>";
		echo "</div>";
	}
}
function actualizarUsuario($firstName, $lastName, $date, $mobile, $phone, $address, $email, $pass_hash, $activo, $token, $latitude, $longitude, $gender, $validarSector, $senate, $referred, $idreferido)
{
	global $mysqli;

	$sqlactualizar = $mysqli->prepare(
		"UPDATE personas SET firstname=?, lastName=?, date=? , mobile=?, phone=?, address=?, email=?, password=?, activacion=?, token=?, latitude=?, longitude=?, gender=?, sectors_idsector=?, candidate_idcandidate=?, persis_idpersis=?  WHERE idpersona = ?"
	);
	$sqlactualizar->bind_param('ssisssssissssiiii', $firstName, $lastName, $date, $mobile, $phone, $address, $email, $pass_hash, $activo, $token, $latitude, $longitude, $gender, $validarSector, $senate, $referred, $idreferido);

	if ($sqlactualizar->execute()) {
		return $idreferido;
	} else {
		return 0;
	}
}
/*Function minMax($min, $max, $valor)
{
	if (strlen(trim($valor)) < $min) {
		return true;
	} else if (strlen(trim($valor)) > $max) {
		return true;
	} else {
		return false;
	}
} 
*/