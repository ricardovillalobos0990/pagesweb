const output = document.getElementById('geo').addEventListener("click", findMe);
const localizacion1 = document.getElementById("latitude");
const localizacion2 = document.getElementById("longitude");
function findMe() {
    // Verificar si soporta geolocalizacion
    if (!navigator.geolocation) {
        alert("Su navegador no soporta geolocalizacion")
    }
    // //Obtenemos latitud y longitud
    function localizacion(posicion) {
        let latitude = posicion.coords.latitude;
        let longitude = posicion.coords.longitude;
        localizacion1.value = `${latitude}`
        localizacion2.value = `${longitude}`
    }
    function error() {
        output.innerHTML = "<p> No se pudo obtener tu ubicación </p>";
    }
    navigator.geolocation.getCurrentPosition(localizacion, error);
}
//FUNCIONES QUE BUSCAN Y CAMBIAN EL DEPARTAMENTO
$(document).ready(() => {
    $("#department").change(() => {
        $('#populated').find('option').remove().end().append('<option value="whatever"></option>').val('whatever');
        $("#department option:selected").each(function () {
            iddepartment = $(this).val();
            $.post("includes/addcity.php", { iddepartment: iddepartment }, function (data) {
                $("#city").html(data);
            })
        })
    })
})
$(document).ready(() => {
    $("#city").change(() => {
        $("#city option:selected").each(function () {
            idciudad = $(this).val();
            $.post("includes/addpopulated.php", { idciudad: idciudad }, function (data) {
                $("#populated").html(data);
            })
        })
    })
})
//EN EL FORMULARIO SI SE DA CLIC EN BORRAR SE SOLICITA CONFIRMACION PARA ENVIAR LA SOLICITUD
function confirmar() {
    let respuesta = confirm("Esta seguro que desea eliminar el usuario");
    if (respuesta == true) {
        return true;
    } else {
        return false;
    }
} 